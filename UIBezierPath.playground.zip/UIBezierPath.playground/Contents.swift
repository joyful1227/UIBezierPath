import UIKit
import PlaygroundSupport

let rect = CGRect(x: 0, y: 0, width: 1000, height: 1000)
let backgroundView = UIView(frame: rect)
backgroundView.backgroundColor = UIColor(red: 27/255, green: 29/255, blue: 75/255, alpha: 1)

var point = CGPoint(x: 376, y: 166) //起始點
let path = UIBezierPath()

path.move(to: point)


//頭髮--------------------------------------------------------------------------
point = CGPoint(x: 370, y: 161); path.addLine(to: point)
point = CGPoint(x: 373, y: 160); path.addLine(to: point)
point = CGPoint(x: 375, y: 146); path.addLine(to: point)
point = CGPoint(x: 381, y: 152); path.addLine(to: point)
point = CGPoint(x: 387, y: 125); path.addLine(to: point)
point = CGPoint(x: 390, y: 135); path.addLine(to: point)
point = CGPoint(x: 402, y: 124); path.addLine(to: point)
point = CGPoint(x: 404, y: 134); path.addLine(to: point)
point = CGPoint(x: 414, y: 128); path.addLine(to: point)
point = CGPoint(x: 426, y: 131); path.addLine(to: point)
point = CGPoint(x: 425, y: 139); path.addLine(to: point)
point = CGPoint(x: 434, y: 140); path.addLine(to: point)
point = CGPoint(x: 432, y: 146); path.addLine(to: point)
point = CGPoint(x: 440, y: 152); path.addLine(to: point)
point = CGPoint(x: 436, y: 156); path.addLine(to: point)
point = CGPoint(x: 442, y: 165); path.addLine(to: point)
point = CGPoint(x: 435, y: 168); path.addLine(to: point)
point = CGPoint(x: 435, y: 176); path.addLine(to: point)
point = CGPoint(x: 429, y: 175); path.addLine(to: point)

//右髮
point = CGPoint(x: 426, y: 183); path.addLine(to: point)
point = CGPoint(x: 424, y: 174); path.addLine(to: point)
point = CGPoint(x: 420, y: 170); path.addLine(to: point)
point = CGPoint(x: 417, y: 168); path.addLine(to: point)
point = CGPoint(x: 400, y: 165); path.addLine(to: point)
point = CGPoint(x: 390, y: 160); path.addLine(to: point)

//左髮
point = CGPoint(x: 377, y: 166); path.addLine(to: point)
point = CGPoint(x: 372, y: 162); path.addLine(to: point)
point = CGPoint(x: 370, y: 161); path.addLine(to: point)
path.close()


//頭髮CAShapeLayer 轉換
let hairShapeLayer = CAShapeLayer()
hairShapeLayer.path = path.cgPath


let hairView = UIView(frame: CGRect(x: 0, y: 0, width: 1000, height: 1000))
hairView.backgroundColor = UIColor(red: 1, green: 249/255, blue: 87/255, alpha: 1)
hairView.layer.mask = hairShapeLayer



//臉-----------------------------------------------------------------------------
let pathForFace = UIBezierPath()

point = CGPoint(x: 377, y: 166)
pathForFace.move(to: point)

pathForFace.addQuadCurve(to: CGPoint(x: 377, y: 199), controlPoint: CGPoint(x: 370, y: 190))
pathForFace.addQuadCurve(to: CGPoint(x: 401, y: 207), controlPoint: CGPoint(x: 385, y: 210))
pathForFace.addQuadCurve(to: CGPoint(x: 426, y: 183), controlPoint: CGPoint(x: 430, y: 195))
pathForFace.addQuadCurve(to: CGPoint(x: 404, y: 143), controlPoint: CGPoint(x: 421, y: 149))
pathForFace.addQuadCurve(to: CGPoint(x: 377, y: 166), controlPoint: CGPoint(x: 384, y: 140))
pathForFace.close()



//臉CAShapeLayer 轉換
let faceShapeLayer = CAShapeLayer()
faceShapeLayer.path = pathForFace.cgPath

let faceView = UIView(frame: CGRect(x: 0, y: 0, width: 1000, height: 1000))
faceView.backgroundColor = UIColor(red: 1, green: 223/255, blue: 199/255, alpha: 1)
faceView.layer.mask = faceShapeLayer



//脖子-----------------------------------------------------------------------------
let pathForNeck = UIBezierPath()

point = CGPoint(x: 390, y: 199)
pathForNeck.move(to: point)

pathForNeck.addQuadCurve(to: CGPoint(x: 388, y: 222), controlPoint: CGPoint(x: 397, y: 211)) //左脖子
pathForNeck.addQuadCurve(to: CGPoint(x: 408, y: 220), controlPoint: CGPoint(x: 398, y: 224)) //脖子下緣
pathForNeck.addQuadCurve(to: CGPoint(x: 408, y: 194), controlPoint: CGPoint(x: 400, y: 207)) //右脖子
pathForNeck.addQuadCurve(to: CGPoint(x: 389, y: 194), controlPoint: CGPoint(x: 396, y: 192)) //脖子上緣
pathForNeck.close()

//脖子CAShapeLayer 轉換
let neckShapeLayer = CAShapeLayer()
neckShapeLayer.path = pathForNeck.cgPath

let neckView = UIView(frame: CGRect(x: 0, y: 0, width: 1000, height: 1000))
neckView.backgroundColor = UIColor(red: 1, green: 225/255, blue: 190/255, alpha: 1)
neckView.layer.mask = neckShapeLayer



//衣服-----------------------------------------------------------------------------
let pathForClothes = UIBezierPath()

point = CGPoint(x: 375, y: 225)
pathForClothes.move(to: point)

pathForClothes.addQuadCurve(to: CGPoint(x: 370, y: 251), controlPoint: CGPoint(x: 375, y: 231)) //左袖
pathForClothes.addQuadCurve(to: CGPoint(x: 384, y: 253), controlPoint: CGPoint(x: 377, y: 255)) //左袖下緣
pathForClothes.addQuadCurve(to: CGPoint(x: 385, y: 270), controlPoint: CGPoint(x: 382, y: 261)) //左上半身
pathForClothes.addQuadCurve(to: CGPoint(x: 380, y: 306), controlPoint: CGPoint(x: 380, y: 286)) //左下肚
pathForClothes.addQuadCurve(to: CGPoint(x: 355, y: 380), controlPoint: CGPoint(x: 367, y: 389)) //左腳褲管
pathForClothes.addQuadCurve(to: CGPoint(x: 383, y: 400), controlPoint: CGPoint(x: 392, y: 394)) //右腳褲管左邊
pathForClothes.addQuadCurve(to: CGPoint(x: 439, y: 403), controlPoint: CGPoint(x: 410, y: 411)) //右腳褲管
pathForClothes.addQuadCurve(to: CGPoint(x: 418, y: 257), controlPoint: CGPoint(x: 414, y: 313)) //右腿
pathForClothes.addQuadCurve(to: CGPoint(x: 435, y: 256), controlPoint: CGPoint(x: 429, y: 261)) //右袖下緣
pathForClothes.addQuadCurve(to: CGPoint(x: 421, y: 222), controlPoint: CGPoint(x: 435, y: 227)) //右肩
pathForClothes.addQuadCurve(to: CGPoint(x: 385, y: 218), controlPoint: CGPoint(x: 393, y: 220)) //領口
//pathForClothes.addQuadCurve(to: CGPoint(x: 440, y: 256), controlPoint: CGPoint(x: 429, y: 261))
pathForClothes.close()

//衣服 CAShapeLayer 轉換
let clothesShapeLayer = CAShapeLayer()
clothesShapeLayer.path = pathForClothes.cgPath

let clothesView = UIView(frame: CGRect(x: 0, y: 0, width: 1000, height: 1000))
clothesView.backgroundColor = UIColor(red: 190/255, green: 255/255, blue: 190/255, alpha: 1)
clothesView.layer.mask = clothesShapeLayer


//蝴蝶結-----------------------------------------------------------------------------
let pathForBow = UIBezierPath()

point = CGPoint(x: 386, y: 212)
pathForBow.move(to: point)

pathForBow.addQuadCurve(to: CGPoint(x: 387, y: 223), controlPoint: CGPoint(x: 384, y: 216)) //左邊
pathForBow.addQuadCurve(to: CGPoint(x: 395, y: 222), controlPoint: CGPoint(x: 394, y: 226)) //結左點
pathForBow.addQuadCurve(to: CGPoint(x: 400, y: 222), controlPoint: CGPoint(x: 396, y: 223)) //結右點
pathForBow.addQuadCurve(to: CGPoint(x: 410, y: 225), controlPoint: CGPoint(x: 401, y: 226)) //右邊下緣
pathForBow.addQuadCurve(to: CGPoint(x: 407, y: 212), controlPoint: CGPoint(x: 410, y: 218)) //右邊
pathForBow.addQuadCurve(to: CGPoint(x: 399, y: 216), controlPoint: CGPoint(x: 403, y: 214)) //右邊上緣
pathForBow.addQuadCurve(to: CGPoint(x: 396, y: 218), controlPoint: CGPoint(x: 397, y: 215)) //結上緣
pathForBow.addQuadCurve(to: CGPoint(x: 386, y: 212), controlPoint: CGPoint(x: 390, y: 210))
pathForBow.close()

//蝴蝶結 CAShapeLayer 轉換
let bowShapeLayer = CAShapeLayer()
bowShapeLayer.path = pathForBow.cgPath

let bowView = UIView(frame: CGRect(x: 0, y: 0, width: 1000, height: 1000))
bowView.backgroundColor = UIColor(red: 0.8, green: 10/255, blue: 10/255, alpha: 1)
bowView.layer.mask = bowShapeLayer

//左手-----------------------------------------------------------------------------
let pathForLeft = UIBezierPath()

point = CGPoint(x: 373, y: 243)
pathForLeft.move(to: point)

pathForLeft.addQuadCurve(to: CGPoint(x: 372, y: 290), controlPoint: CGPoint(x: 378, y: 268)) //左手臂1
pathForLeft.addQuadCurve(to: CGPoint(x: 380, y: 317), controlPoint: CGPoint(x: 366, y: 310)) //左手臂2
pathForLeft.addQuadCurve(to: CGPoint(x: 387, y: 303), controlPoint: CGPoint(x: 384, y: 313)) //左手下緣
pathForLeft.addQuadCurve(to: CGPoint(x: 386, y: 240), controlPoint: CGPoint(x: 395, y: 259)) //左手右邊
pathForLeft.addQuadCurve(to: CGPoint(x: 373, y: 243), controlPoint: CGPoint(x: 375, y: 237)) //左手上面
pathForLeft.close()

//左手 CAShapeLayer 轉換
let leftShapeLayer = CAShapeLayer()
leftShapeLayer.path = pathForLeft.cgPath

let leftView = UIView(frame: CGRect(x: 0, y: 0, width: 1000, height: 1000))
leftView.backgroundColor = UIColor(red: 1, green: 223/255, blue: 199/255, alpha: 1)
leftView.layer.mask = leftShapeLayer


//右手-----------------------------------------------------------------------------
let pathForRight = UIBezierPath()

point = CGPoint(x: 419, y: 256)
pathForRight.move(to: point)

pathForRight.addQuadCurve(to: CGPoint(x: 419, y: 292), controlPoint: CGPoint(x: 421, y: 281)) //左手臂1
pathForRight.addQuadCurve(to: CGPoint(x: 406, y: 325), controlPoint: CGPoint(x: 416, y: 319)) //左手臂2
pathForRight.addQuadCurve(to: CGPoint(x: 416, y: 334), controlPoint: CGPoint(x: 408, y: 334)) //左手下緣
pathForRight.addQuadCurve(to: CGPoint(x: 434, y: 256), controlPoint: CGPoint(x: 438, y: 297)) //左手右邊
pathForRight.addQuadCurve(to: CGPoint(x: 419, y: 256), controlPoint: CGPoint(x: 428, y: 254)) //左手上面
pathForRight.close()

//右手 CAShapeLayer 轉換
let rightShapeLayer = CAShapeLayer()
rightShapeLayer.path = pathForRight.cgPath

let rightView = UIView(frame: CGRect(x: 0, y: 0, width: 1000, height: 1000))
rightView.backgroundColor = UIColor(red: 1, green: 223/255, blue: 199/255, alpha: 1)
rightView.layer.mask = rightShapeLayer



//腰帶-----------------------------------------------------------------------------
let pathForBelt = UIBezierPath()

point = CGPoint(x: 384, y: 271)
pathForBelt.move(to: point)

pathForBelt.addQuadCurve(to: CGPoint(x: 384, y: 276), controlPoint: CGPoint(x: 380, y: 272)) //左弧
pathForBelt.addQuadCurve(to: CGPoint(x: 419, y: 290), controlPoint: CGPoint(x: 401, y: 277)) //下弧
pathForBelt.addQuadCurve(to: CGPoint(x: 421, y: 284), controlPoint: CGPoint(x: 408, y: 334)) //右糊
pathForBelt.addQuadCurve(to: CGPoint(x: 384, y: 271), controlPoint: CGPoint(x: 401, y: 273)) //上湖

pathForBelt.close()

//belt CAShapeLayer 轉換
let beltShapeLayer = CAShapeLayer()
beltShapeLayer.path = pathForBelt.cgPath

let beltView = UIView(frame: CGRect(x: 0, y: 0, width: 1000, height: 1000))
beltView.backgroundColor = UIColor(red: 0.8, green: 10/255, blue: 80/255, alpha: 1)
beltView.layer.mask = beltShapeLayer



//線-----------------------------------------------------------------------------
let pathForLine = UIBezierPath()

point = CGPoint(x: 396, y: 237)
pathForLine.move(to: point)

pathForLine.addQuadCurve(to: CGPoint(x: 391, y: 275), controlPoint: CGPoint(x: 392, y: 251))
pathForLine.close()

//belt CAShapeLayer 轉換
let lineShapeLayer = CAShapeLayer()
lineShapeLayer.path = pathForLine.cgPath

let lineView = UIView(frame: CGRect(x: 0, y: 0, width: 1000, height: 1000))
lineView.backgroundColor = UIColor.darkGray
lineView.layer.mask = lineShapeLayer



//鈕扣1-----------------------------------------------------------------------------
let pathForbutton = UIBezierPath()

point = CGPoint(x: 401, y: 238)
pathForbutton.move(to: point)

pathForbutton.addQuadCurve(to: CGPoint(x: 398, y: 241), controlPoint: CGPoint(x: 398, y: 238))
pathForbutton.addQuadCurve(to: CGPoint(x: 401, y: 244), controlPoint: CGPoint(x: 398, y: 244))
pathForbutton.addQuadCurve(to: CGPoint(x: 404, y: 241), controlPoint: CGPoint(x: 404, y: 244))
pathForbutton.addQuadCurve(to: CGPoint(x: 401, y: 238), controlPoint: CGPoint(x: 404, y: 239))
pathForbutton.close()

//belt CAShapeLayer 轉換
let buttonShapeLayer = CAShapeLayer()
buttonShapeLayer.path = pathForbutton.cgPath

let buttonView = UIView(frame: CGRect(x: 0, y: 0, width: 1000, height: 1000))
buttonView.backgroundColor = UIColor.darkGray
buttonView.layer.mask = buttonShapeLayer

//鈕扣2-----------------------------------------------------------------------------
let pathForbutton2 = UIBezierPath()

point = CGPoint(x: 398, y: 255)
pathForbutton2.move(to: point)

pathForbutton2.addQuadCurve(to: CGPoint(x: 395, y: 258), controlPoint: CGPoint(x: 395, y: 255))
pathForbutton2.addQuadCurve(to: CGPoint(x: 398, y: 261), controlPoint: CGPoint(x: 395, y: 261))
pathForbutton2.addQuadCurve(to: CGPoint(x: 401, y: 258), controlPoint: CGPoint(x: 401, y: 261))
pathForbutton2.addQuadCurve(to: CGPoint(x: 398, y: 255), controlPoint: CGPoint(x: 401, y: 256))
pathForbutton2.close()

// CAShapeLayer 轉換
let button2ShapeLayer = CAShapeLayer()
button2ShapeLayer.path = pathForbutton2.cgPath

let button2View = UIView(frame: CGRect(x: 0, y: 0, width: 1000, height: 1000))
button2View.backgroundColor = UIColor.darkGray
button2View.layer.mask = button2ShapeLayer


//shoe1---left-------------------------------------------------------------------
let pathForshoe1 = UIBezierPath()

point = CGPoint(x: 363, y: 383)
pathForshoe1.move(to: point)

pathForshoe1.addQuadCurve(to: CGPoint(x: 349, y: 393), controlPoint: CGPoint(x: 352, y: 385))
pathForshoe1.addQuadCurve(to: CGPoint(x: 380, y: 390), controlPoint: CGPoint(x: 366, y: 398))
pathForshoe1.addQuadCurve(to: CGPoint(x: 363, y: 383), controlPoint: CGPoint(x: 372, y: 379))
pathForshoe1.close()

// CAShapeLayer 轉換
let shoe1ShapeLayer = CAShapeLayer()
shoe1ShapeLayer.path = pathForshoe1.cgPath

let shoe1View = UIView(frame: CGRect(x: 0, y: 0, width: 1000, height: 1000))
shoe1View.backgroundColor = UIColor.darkGray
shoe1View.layer.mask = shoe1ShapeLayer


//shoe1---right-------------------------------------------------------------------
let pathForshoe2 = UIBezierPath()

point = CGPoint(x: 383, y: 403)
pathForshoe2.move(to: point)

pathForshoe2.addQuadCurve(to: CGPoint(x: 369, y: 413), controlPoint: CGPoint(x: 372, y: 405))
pathForshoe2.addQuadCurve(to: CGPoint(x: 410, y: 405), controlPoint: CGPoint(x: 386, y: 418))
pathForshoe2.addQuadCurve(to: CGPoint(x: 383, y: 403), controlPoint: CGPoint(x: 392, y: 399))
pathForshoe2.close()

// CAShapeLayer 轉換
let shoe2ShapeLayer = CAShapeLayer()
shoe2ShapeLayer.path = pathForshoe2.cgPath

let shoe2View = UIView(frame: CGRect(x: 0, y: 0, width: 1000, height: 1000))
shoe2View.backgroundColor = UIColor.darkGray
shoe2View.layer.mask = shoe2ShapeLayer




//nose-----------------------------------------------------------------------------
let pathForNose = UIBezierPath()

point = CGPoint(x: 388, y: 185)
pathForNose.move(to: point)

pathForNose.addQuadCurve(to: CGPoint(x: 386, y: 195), controlPoint: CGPoint(x: 390, y: 186))
pathForNose.close()

//belt CAShapeLayer 轉換
let noseShapeLayer = CAShapeLayer()
noseShapeLayer.path = pathForNose.cgPath

let noseView = UIView(frame: CGRect(x: 0, y: 0, width: 1000, height: 1000))
noseView.backgroundColor = UIColor.darkGray
noseView.layer.mask = noseShapeLayer



//eye-right----------------------------------------------------------------------------
let pathForEye1 = UIBezierPath()

point = CGPoint(x: 395, y: 184)
pathForEye1.move(to: point)

pathForEye1.addQuadCurve(to: CGPoint(x: 410, y: 186), controlPoint: CGPoint(x: 400, y: 190))
pathForEye1.addQuadCurve(to: CGPoint(x: 395, y: 184), controlPoint: CGPoint(x: 400, y: 187))
pathForEye1.close()

//belt CAShapeLayer 轉換
let eye1ShapeLayer = CAShapeLayer()
eye1ShapeLayer.path = pathForEye1.cgPath

let eye1View = UIView(frame: CGRect(x: 0, y: 0, width: 1000, height: 1000))
eye1View.backgroundColor = UIColor.darkGray
eye1View.layer.mask = eye1ShapeLayer




//eye-left----------------------------------------------------------------------------
let pathForEye2 = UIBezierPath()

point = CGPoint(x: 375, y: 184)
pathForEye2.move(to: point)

pathForEye2.addQuadCurve(to: CGPoint(x: 383, y: 186), controlPoint: CGPoint(x: 375, y: 190))
pathForEye2.addQuadCurve(to: CGPoint(x: 375, y: 184), controlPoint: CGPoint(x: 375, y: 187))
pathForEye2.close()

//belt CAShapeLayer 轉換
let eye2ShapeLayer = CAShapeLayer()
eye2ShapeLayer.path = pathForEye2.cgPath

let eye2View = UIView(frame: CGRect(x: 0, y: 0, width: 1000, height: 1000))
eye2View.backgroundColor = UIColor.darkGray
eye2View.layer.mask = eye2ShapeLayer






//Moon----------------------------------------------------------------------------
let pathForMoon = UIBezierPath()

point = CGPoint(x: 140, y: 440)
pathForMoon.move(to: point)

pathForMoon.addQuadCurve(to: CGPoint(x: 334, y: 380), controlPoint: CGPoint(x: 217, y: 382))
pathForMoon.addQuadCurve(to: CGPoint(x: 493, y: 433), controlPoint: CGPoint(x: 406, y: 372))
pathForMoon.addQuadCurve(to: CGPoint(x: 140, y: 440), controlPoint: CGPoint(x: 336, y: 445))
pathForMoon.close()

//belt CAShapeLayer 轉換
let moonShapeLayer = CAShapeLayer()
moonShapeLayer.path = pathForMoon.cgPath

let moonView = UIView(frame: CGRect(x: 0, y: 0, width: 1000, height: 1000))
moonView.backgroundColor = UIColor.white
moonView.layer.mask = moonShapeLayer



//Root----------------------------------------------------------------------------
let pathForRoot = UIBezierPath()

point = CGPoint(x: 198, y: 420)
pathForRoot.move(to: point)

pathForRoot.addQuadCurve(to: CGPoint(x: 164, y: 364), controlPoint: CGPoint(x: 184, y: 405))
pathForRoot.addQuadCurve(to: CGPoint(x: 152, y: 358), controlPoint: CGPoint(x: 156, y: 360))
pathForRoot.addQuadCurve(to: CGPoint(x: 164, y: 359), controlPoint: CGPoint(x: 159, y: 358))
pathForRoot.addQuadCurve(to: CGPoint(x: 170, y: 346), controlPoint: CGPoint(x: 164, y: 353))
pathForRoot.addQuadCurve(to: CGPoint(x: 170, y: 362), controlPoint: CGPoint(x: 172, y: 360))
pathForRoot.addQuadCurve(to: CGPoint(x: 210, y: 420), controlPoint: CGPoint(x: 183, y: 396))
pathForRoot.addQuadCurve(to: CGPoint(x: 198, y: 420), controlPoint: CGPoint(x: 200, y: 430))
pathForRoot.close()

//root CAShapeLayer 轉換
let rootShapeLayer = CAShapeLayer()
rootShapeLayer.path = pathForRoot.cgPath

let rootView = UIView(frame: CGRect(x: 0, y: 0, width: 1000, height: 1000))
rootView.backgroundColor = UIColor(red: 10/255, green: 0.8, blue: 100/255, alpha: 1)
rootView.layer.mask = rootShapeLayer



//Rose----------------------------------------------------------------------------
let pathForRose = UIBezierPath()

point = CGPoint(x: 164, y: 364)
pathForRose.move(to: point)

pathForRose.addQuadCurve(to: CGPoint(x: 145, y: 348), controlPoint: CGPoint(x: 150, y: 360))
pathForRose.addQuadCurve(to: CGPoint(x: 170, y: 336), controlPoint: CGPoint(x: 160, y: 335))
pathForRose.addQuadCurve(to: CGPoint(x: 170, y: 362), controlPoint: CGPoint(x: 173, y: 353))
pathForRose.addQuadCurve(to: CGPoint(x: 164, y: 364), controlPoint: CGPoint(x: 164, y: 353))
pathForRose.close()

//Rose CAShapeLayer 轉換
let roseShapeLayer = CAShapeLayer()
roseShapeLayer.path = pathForRose.cgPath

let roseView = UIView(frame: CGRect(x: 0, y: 0, width: 1000, height: 1000))
roseView.backgroundColor = UIColor(red: 0.85, green: 80/255, blue: 80/255, alpha: 1)
roseView.layer.mask = roseShapeLayer




//Rose2----------------------------------------------------------------------------
let pathForRose2 = UIBezierPath()

point = CGPoint(x: 164, y: 364)
pathForRose2.move(to: point)

pathForRose2.addQuadCurve(to: CGPoint(x: 145, y: 348), controlPoint: CGPoint(x: 150, y: 360))
pathForRose2.addQuadCurve(to: CGPoint(x: 150, y: 338), controlPoint: CGPoint(x: 140, y: 340))
pathForRose2.addQuadCurve(to: CGPoint(x: 168, y: 345), controlPoint: CGPoint(x: 164, y: 340))
pathForRose2.addQuadCurve(to: CGPoint(x: 164, y: 364), controlPoint: CGPoint(x: 164, y: 353))

pathForRose2.close()

//belt CAShapeLayer 轉換
let rose2ShapeLayer = CAShapeLayer()
rose2ShapeLayer.path = pathForRose2.cgPath

let rose2View = UIView(frame: CGRect(x: 0, y: 0, width: 1000, height: 1000))
rose2View.backgroundColor = UIColor(red: 0.85, green: 50/255, blue: 50/255, alpha: 1)
rose2View.layer.mask = rose2ShapeLayer



//fallRose------------------------------------------------------------------
let pathForFallRose = UIBezierPath()

point = CGPoint(x: 226, y: 430)
pathForFallRose.move(to: point)

pathForFallRose.addQuadCurve(to: CGPoint(x: 245, y: 424), controlPoint: CGPoint(x: 235, y: 418))
pathForFallRose.addQuadCurve(to: CGPoint(x: 246, y: 429), controlPoint: CGPoint(x: 253, y: 425))
pathForFallRose.addQuadCurve(to: CGPoint(x: 226, y: 430), controlPoint: CGPoint(x: 237, y: 432))
pathForFallRose.close()

//belt CAShapeLayer 轉換
let fallRoseShapeLayer = CAShapeLayer()
fallRoseShapeLayer.path = pathForFallRose.cgPath

let fallRoseView = UIView(frame: CGRect(x: 0, y: 0, width: 1000, height: 1000))
fallRoseView.backgroundColor = UIColor(red: 0.85, green: 50/255, blue: 50/255, alpha: 1)
fallRoseView.layer.mask = fallRoseShapeLayer






//疊圖

backgroundView.addSubview(moonView)
backgroundView.addSubview(fallRoseView)
backgroundView.addSubview(rose2View)
backgroundView.addSubview(roseView)
backgroundView.addSubview(rootView)
backgroundView.addSubview(leftView)
backgroundView.addSubview(neckView)
backgroundView.addSubview(faceView)
backgroundView.addSubview(hairView)
backgroundView.addSubview(noseView)
backgroundView.addSubview(eye1View)
backgroundView.addSubview(eye2View)
backgroundView.addSubview(shoe1View)
backgroundView.addSubview(shoe2View)
backgroundView.addSubview(clothesView)
backgroundView.addSubview(lineView)
backgroundView.addSubview(buttonView)
backgroundView.addSubview(button2View)
backgroundView.addSubview(beltView)
backgroundView.addSubview(rightView)
backgroundView.addSubview(bowView)

PlaygroundPage.current.liveView = backgroundView
